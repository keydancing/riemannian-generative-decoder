Optimizers
==========

.. currentmodule:: geoopt.optim

.. automodule:: geoopt.optim
   :members:
   :imported-members: True
