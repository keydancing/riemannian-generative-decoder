Tensors
=======

.. currentmodule:: geoopt.tensor

.. automodule:: geoopt.tensor
   :members:
