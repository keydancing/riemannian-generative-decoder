Extended Guide
==============

.. toctree::
   :maxdepth: 1

   extended/stereographic
