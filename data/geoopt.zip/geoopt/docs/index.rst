.. geoopt documentation master file, created by
   sphinx-quickstart on Sat Dec 29 02:32:30 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to geoopt's documentation!
==================================

.. include:: ../README.rst

API
===
.. toctree::
   :maxdepth: 2

   manifolds
   optimizers
   tensors
   samplers
   extended
   devguide

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
